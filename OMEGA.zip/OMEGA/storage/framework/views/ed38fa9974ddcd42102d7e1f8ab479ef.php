<?php $__env->startSection('content'); ?>

<h2>Criar</h2>

<?php if(session()->has('message')): ?>
    <?php echo e(session()->get('message')); ?>

<?php endif; ?>


<form action="<?php echo e(route ('users.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" placeholder="Nome" value="Alex">
    <input type="text" name="email" placeholder="Email" value="Xavier@gmail.com">
    <input type="text" name="email" placeholder="psw" value="12345678">
    <button type="submit">Criar</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/matheusestrela/Documents/GitHub/omega_git/OMEGA/resources/views/admin/alunos/user_create.blade.php ENDPATH**/ ?>