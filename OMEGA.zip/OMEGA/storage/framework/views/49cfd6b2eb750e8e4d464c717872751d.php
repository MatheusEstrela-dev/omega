<?php $__env->startSection('content'); ?>

<h2>Lista de Exercícios</h2>

<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Tipo</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $exercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($exercicio->Id_Exerc); ?></td>
            <td><?php echo e($exercicio->NomeExercicio); ?></td>
            <td><?php echo e($exercicio->Tipo_Exerc); ?></td>
            <td>
                <a href="<?php echo e(route('exercicios.edit', $exercicio->Id_Exerc)); ?>" class="btn btn-warning">Editar</a>
                <form action="<?php echo e(route('exercicios.destroy', $exercicio->Id_Exerc)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Deletar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/matheusestrela/Documents/GitHub/omega_git/OMEGA/resources/views/admin/exercicios/exercicios.blade.php ENDPATH**/ ?>