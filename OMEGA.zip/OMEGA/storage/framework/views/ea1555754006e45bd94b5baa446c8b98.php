<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cadastro</title>
</head>

<body>

    <header class="Cabecalho">

        <img src="<?php echo e(asset('img/Olimp.svg')); ?>" alt="academiaolimpo" class="logo" width="400x" height="400px">

    </header>

    <main class="Cadastro">

        <div class="background">

            <div id="CADASTRO">
                <h2>CADASTRO</h2>

                <?php if(session('success')): ?>
                <p style="color: green;"><?php echo e(session('success')); ?></p>
                <?php endif; ?>

            </div>

            <form action="<?php echo e(route('alunos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?> <!-- Token de segurança necessário -->

                <label for="Nome">Nome:</label><br>
                <input type="text" id="nome" name="nome" class="formCadastro" value="<?php echo e(old('nome')); ?>"><br><br>

                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" class="formCadastro" value="<?php echo e(old('email')); ?>"><br><br>

                <label for="senha">Senha:</label><br>
                <input type="password" id="senha" name="senha" class="formCadastro"><br><br>

                <label for="CPF">CPF:</label><br>
                <input type="text" id="cpf" name="cpf" class="formCadastro" value="<?php echo e(old('cpf')); ?>"><br><br>

                <button type="submit" class="btn">Cadastrar</button>

            </form>

            <!-- Exibição de erros de validação -->
            <?php if($errors->any()): ?>
            <div style="color: red;">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
<?php /**PATH /Users/matheusestrela/Documents/GitHub/omega_git/OMEGA/resources/views/home/cadastro.blade.php ENDPATH**/ ?>