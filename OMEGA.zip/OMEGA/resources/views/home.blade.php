@extends('master')

@section('content')

<h2>Home</h2>

@endsection
