<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route ('users.create')); ?>">Criar</a>

<h2>Usuarios</h2>

<ul>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($user->name); ?> | <a href="<?php echo e(route('users.edit', ['user' => $user->id])); ?>">Editar</a> | <a href="<?php echo e(route ('users.show', ['user'=> $user->id])); ?>">Deletar</a></li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/matheusestrela/Desktop/OMEGA/OMEGA/resources/views/admin/alunos/users.blade.php ENDPATH**/ ?>