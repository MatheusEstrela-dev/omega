<?php $__env->startSection('content'); ?>

<h2>Usuario - <?php echo e($user->name); ?></h2>


<form action="<?php echo e(route ('users.destroy', ['user' => $user->id])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="DELETE">
    <button type="submit">Deletar</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/matheusestrela/Desktop/OMEGA/OMEGA/resources/views/admin/alunos/user_delete.blade.php ENDPATH**/ ?>