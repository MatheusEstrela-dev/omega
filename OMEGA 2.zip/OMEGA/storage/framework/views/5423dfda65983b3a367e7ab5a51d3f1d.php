<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="CRUD Application">
    <meta name="keywords" content="crud, application">
    <title>Pagina do Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
</head>
<body>
 <H2>PAGINA ADMIN</H2>
 <h1>Bem-vindo, Admin: <?php echo e(Session::get('user_name')); ?></h1>
 <a href="/logout">Sair</a>
        <div class="botoes">
            <button type="button" onclick="window.location.href='<?php echo e(url('admin/alunos/users')); ?>';" class="btn">Excluir Perfil</button>
        <button type="submit" class="btn" onclick="window.location.href='<?php echo e(url('admin/exercicios/editarexercicios')); ?>';">Editar Biblioteca de Exercícios </button>
        </div>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('script.js')); ?>"></script>
</body>
</html>

<?php /**PATH /Users/matheusestrela/Documents/GitHub/omega_git/OMEGA/resources/views/admin/adminpage.blade.php ENDPATH**/ ?>